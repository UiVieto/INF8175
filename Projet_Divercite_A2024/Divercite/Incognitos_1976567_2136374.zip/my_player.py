from player_divercite import PlayerDivercite
from seahorse.game.action import Action
from seahorse.game.game_state import GameState
from game_state_divercite import GameStateDivercite
from seahorse.utils.custom_exceptions import MethodNotImplementedError

class MyPlayer(PlayerDivercite):
    """
    Player class for Divercite game that makes random moves.

    Attributes:
        piece_type (str): piece type of the player
    """

    def __init__(self, piece_type: str, name: str = "ShallowMinMax"):
        """
        Initialize the PlayerDivercite instance.

        Args:
            piece_type (str): Type of the player's game piece
            name (str, optional): Name of the player (default is "bob")
            time_limit (float, optional): the time limit in (s)
        """
        super().__init__(piece_type, name)

    def compute_action(self, current_state: GameState, remaining_time: int = 1e9, **kwargs) -> Action:
        """
        Use the minimax algorithm to choose the best action based on the heuristic evaluation of game states.

        Args:
            current_state (GameState): The current game state.

        Returns:
            Action: The best action as determined by minimax.
        """

        def maxValue(current_state: GameState, a: int, b: int, turns_to_search: int = 2,  remaining_time: int = 1e9) -> tuple[int, any]:
            if turns_to_search == 0:
                return current_state.scores[self.get_id()], None
            
            best_score = -999999
            best_action = None

            for action in current_state.generate_possible_heavy_actions():
                state = action.get_next_game_state()
                score, _ = minValue(state, a, b, turns_to_search - 1, remaining_time)

                if score > best_score:
                    best_score = score
                    best_action = action
                    a = max(a, best_score)

                if best_score >= b:
                    return best_score, best_action

            return best_score, best_action
        
        def minValue(current_state: GameState, a: int, b: int, turns_to_search: int = 2, remaining_time: int = 1e9) -> tuple[int, any]:
            if turns_to_search == 0:
                return current_state.scores[self.get_id()], None
            
            worst_score = 999999
            worst_action = None

            for action in current_state.generate_possible_heavy_actions():
                state = action.get_next_game_state()
                score, _ = maxValue(state, a, b, turns_to_search - 1, remaining_time)

                if score < worst_score:
                    worst_score = score
                    worst_action = action
                    b = min(b, worst_score)

                if worst_score <= a:
                    return worst_score, worst_action

            return worst_score, worst_action
            

        _, best_action = maxValue(current_state, -999999, 999999)

        return best_action
